package org.ytu.adem.datacollector.enums;

/**
 * Created by Adem on 24.12.2017.
 */

public enum Action {
    START, STOP;
}
